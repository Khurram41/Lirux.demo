Lirux Creator Tools — Demo Version (Frontend-only)

This demo is frontend-only. It simulates users, credits, and purchases using localStorage.
Deploy instantly on Vercel (Upload project) to get a live preview link.

How to run locally:
1. npm install
2. npm run dev
3. Open http://localhost:3000

Deploy on Vercel: New Project -> Upload Project -> select this ZIP.
