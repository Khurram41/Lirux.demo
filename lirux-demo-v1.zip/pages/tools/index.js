import Link from 'next/link'
import tools from '../../utils/tools-data'

export default function Tools() {
  return (
    <main className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Tools</h2>
      <div className="grid md:grid-cols-3 gap-4">
        {tools.map(t => (
          <div key={t.id} className="bg-white p-4 rounded shadow">
            <div className="font-semibold">{t.name}</div>
            <div className="text-sm text-slate-500">{t.description}</div>
            <div className="mt-3 flex items-center justify-between">
              <div className="text-sm">Cost: {t.cost === 0 ? 'Free' : t.cost + ' credit(s)'}</div>
              <Link href={`/tools/${t.id}`}><a className="px-3 py-1 rounded border text-sm">Open</a></Link>
            </div>
          </div>
        ))}
      </div>
    </main>
  )
}
